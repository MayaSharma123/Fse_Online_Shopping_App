package com.shoppingapp.OnlineShoppingApp.service;

import com.shoppingapp.OnlineShoppingApp.exception.OrderNotFoundException;
import com.shoppingapp.OnlineShoppingApp.model.Order;

import java.util.List;

public interface OrderService {
    public List<Order> getAllOrdersByUser(String loginId) throws OrderNotFoundException;

    public Order placeOrder(Order order) throws OrderNotFoundException;
}
