package com.shoppingapp.OnlineShoppingApp.model;


import lombok.Data;
import org.springframework.data.annotation.Id;


@Data
public class UserInfo {
   @Id
    private String id;
    private String loginId;
    private String firstName;
    private String lastName;
    private String password;
    private String confirmPassword;
    private String email;
    private String roles;
    private String resetPasswordToken;
    private Long contactNumber;

    public String getLoginId() {
        return loginId;
    }

    public void setLoginId(String loginId) {
        this.loginId = loginId;
    }
}
