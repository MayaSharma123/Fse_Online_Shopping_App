package com.shoppingapp.OnlineShoppingApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineShoppingAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
